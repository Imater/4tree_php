//
//  ViewController.m
//  ActionPicker
//
//  Created by Eugene Romanishin on 25.01.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    NSArray *dataSource = [NSArray arrayWithObjects:
                           @"Objective C", 
                           @"C",
                           @"C++",
                           @"Java",
                           @"Pascal",
                           @"Delphi", nil];
    
    UNActionPicker *actionPicker = [[UNActionPicker alloc] initWithItems:dataSource title:@"iMaladec"];
    [actionPicker setActionSheetStyle:UIActionSheetStyleBlackTranslucent];
    [actionPicker setCloseButtonTitle:@"Done" color:[UIColor blackColor]];
    actionPicker.delegate = self;
    [actionPicker showInView:self.view];
}

- (void)didSelectItem:(id)item {
    NSLog(@"%@", item);
}

@end
